void hello_from_static_lib();
