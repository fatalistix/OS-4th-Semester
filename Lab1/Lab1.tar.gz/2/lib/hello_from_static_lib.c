#include <stdio.h>

#include "hello_from_static_lib.h"

void hello_from_static_lib()
{
	printf( "Hello, World!\n" );
}
