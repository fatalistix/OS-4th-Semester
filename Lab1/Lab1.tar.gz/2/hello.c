#include "lib/hello_from_static_lib.h"


int main()
{
	hello_from_static_lib();
	return 0;
}
