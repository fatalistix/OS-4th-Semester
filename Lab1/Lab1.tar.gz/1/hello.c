#include <stdio.h>

void printHelloWorld()
{
	printf("Hello, World!\n");
}

int main()
{
	printHelloWorld();
	return 0;
}
