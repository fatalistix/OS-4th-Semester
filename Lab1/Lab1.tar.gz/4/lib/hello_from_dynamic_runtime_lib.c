#include <stdio.h>

#include "hello_from_dynamic_runtime_lib.h"

void hello_from_dynamic_lib()
{
	printf( "Hello, World!\n" );
}
