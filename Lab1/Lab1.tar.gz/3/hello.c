#include "lib/hello_from_dynamic_lib.h"

int main()
{
	hello_from_dynamic_lib();
}
