void hello_from_dynamic_lib();
